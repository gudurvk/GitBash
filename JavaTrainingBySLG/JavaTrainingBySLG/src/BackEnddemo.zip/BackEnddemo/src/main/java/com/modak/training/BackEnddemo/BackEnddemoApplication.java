package com.modak.training.BackEnddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackEnddemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackEnddemoApplication.class, args);
	}

}
